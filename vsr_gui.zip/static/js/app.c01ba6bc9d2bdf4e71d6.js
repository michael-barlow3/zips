webpackJsonp([1],{

/***/ "+ku2":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "AR0u":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "JW98":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "L0+G":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "NHnr":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });

// EXTERNAL MODULE: ./node_modules/vue/dist/vue.esm.js
var vue_esm = __webpack_require__("7+uW");

// EXTERNAL MODULE: ./node_modules/mdbvue/lib/index.js
var lib = __webpack_require__("vj/V");
var lib_default = /*#__PURE__*/__webpack_require__.n(lib);

// EXTERNAL MODULE: ./node_modules/vue-select/dist/vue-select.js
var vue_select = __webpack_require__("T1ft");
var vue_select_default = /*#__PURE__*/__webpack_require__.n(vue_select);

// EXTERNAL MODULE: ./node_modules/classnames/index.js
var classnames = __webpack_require__("HW6M");
var classnames_default = /*#__PURE__*/__webpack_require__.n(classnames);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/components/components/MQARISideNav.vue
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




var SideNav = {
  props: {
    PatientLookupResults: '',

    logoAlt: {
      type: String,
      default: ""
    },

    tag: {
      type: String,
      default: "div"
    },
    fixed: {
      type: Boolean,
      default: false
    },
    right: {
      type: Boolean,
      default: false
    },
    hidden: {
      type: Boolean
    },
    logo: {
      type: String
    },
    logoClass: {
      type: String
    },
    href: {
      type: String,
      default: '#'
    },
    to: {
      type: String
    },
    breakWidth: {
      type: Number,
      default: 1440
    },
    OpenedFromOutside: {
      type: Boolean,
      default: false
    },
    color: {
      type: String
    },
    sideNavClass: {
      type: String
    },
    mask: {
      type: String
    },
    logoSn: {
      type: Boolean,
      default: false
    },
    logoRound: {
      type: Boolean,
      default: false
    },
    sideNavStyle: {
      type: [Object, String]
    },
    slim: {
      type: Boolean,
      default: false
    },
    isCollapsed: {
      type: Boolean,
      default: false
    },
    name: String
  },
  data: function data() {
    return {
      isThere: false
    };
  },

  computed: {
    collapsed: function collapsed() {
      return this.isCollapsed;
    },
    slideSide: function slideSide() {
      if (this.right) {
        return "slideRight";
      }
      return "slideLeft";
    },
    className: function className() {
      return classnames_default()('side-nav', 'wide', this.collapsed && 'slim', this.fixed && 'fixed', this.color, this.sideNavClass, this.right ? 'right-aligned ' : '');
    },
    logoClasses: function logoClasses() {
      return classnames_default()(this.logoSn ? '' : 'img-fluid', this.logoClass, this.logoRound ? 'rounded-circle' : '');
    },
    logoLi: function logoLi() {
      return classnames_default()(this.logoSn && 'logo-sn', 'ripple-parent');
    },
    logoWrapperClasses: function logoWrapperClasses() {
      return classnames_default()(this.logoSn ? '' : 'logo-wrapper', this.slim ? 'sn-ad-avatar-wrapper' : '', this.name ? '' : 'text-center');
    },
    maskClasses: function maskClasses() {
      return classnames_default()('sidenav-bg', 'mask-' + this.mask);
    }
  },
  methods: {
    updatePredicate: function updatePredicate() {
      if (!this.hidden) {
        this.isThere = window.innerWidth > this.breakWidth;
      }
    },
    handleOverlayClick: function handleOverlayClick() {
      console.log("SideNav.vue - update:OpenedFromOutside");
      this.$emit("update:OpenedFromOutside", !this.OpenedFromOutside);
    }
  },
  mounted: function mounted() {
    this.updatePredicate();
    window.addEventListener("resize", this.updatePredicate);
  },
  beforeDestroy: function beforeDestroy() {
    window.removeEventListener("resize", this.updatePredicate);
  },

  components: {
    mdbScrollbar: lib["mdbScrollbar"]
  },
  mixins: [lib["waves"]]
};

/* harmony default export */ var MQARISideNav = (SideNav);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-243af498","hasScoped":true,"transformToRequire":{"video":["src","poster"],"source":"src","img":"src","image":"xlink:href"},"buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/components/MQARISideNav.vue
var MQARISideNav_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',[_c('transition',{attrs:{"name":_vm.slideSide}},[(_vm.isThere)?_c(_vm.tag,{tag:"component",class:_vm.className,style:(_vm.sideNavStyle)},[_c('mdb-scrollbar',[_c('ul',{staticClass:"custom-scrollbar list-unstyled"},[(_vm.logo)?_c('li',{class:_vm.logoLi},[_c('div',{class:_vm.logoWrapperClasses},[_c('img',{class:_vm.logoClasses,attrs:{"src":_vm.logo,"alt":_vm.logoAlt}}),_vm._v(" "),(!_vm.collapsed && _vm.slim && _vm.name)?_c('span',[_vm._v(_vm._s(_vm.name))]):_vm._e()])]):_vm._e(),_vm._v(" "),_vm._t("default")],2)]),_vm._v(" "),(_vm.mask)?_c('div',{class:_vm.maskClasses}):_vm._e()],1):_vm._e()],1),_vm._v(" "),(!_vm.isThere && _vm.OpenedFromOutside)?_c('div',{attrs:{"id":"sidenav-overlay"}}):_vm._e()],1)}
var staticRenderFns = []
var esExports = { render: MQARISideNav_render, staticRenderFns: staticRenderFns }
/* harmony default export */ var components_MQARISideNav = (esExports);
// CONCATENATED MODULE: ./src/components/components/MQARISideNav.vue
function injectStyle (ssrContext) {
  __webpack_require__("SDKv")
}
var normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var __vue_template_functional__ = false
/* styles */
var __vue_styles__ = injectStyle
/* scopeId */
var __vue_scopeId__ = "data-v-243af498"
/* moduleIdentifier (server only) */
var __vue_module_identifier__ = null
var Component = normalizeComponent(
  MQARISideNav,
  components_MQARISideNav,
  __vue_template_functional__,
  __vue_styles__,
  __vue_scopeId__,
  __vue_module_identifier__
)

/* harmony default export */ var components_components_MQARISideNav = (Component.exports);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/components/SideNav.vue
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//







/* harmony default export */ var components_SideNav = ({
  name: "SideNav",

  props: {
    PatientLookupResults: "",
    waves: {
      type: Boolean,
      default: true
    }
  },

  components: {
    mdbBtn: lib["mdbBtn"],
    mdbInput: lib["mdbInput"],
    mdbContainer: lib["mdbContainer"],
    mdbSelect: lib["mdbSelect"],
    mdbSideNav: components_components_MQARISideNav,
    mdbSideNavNav: lib["mdbSideNavNav"],
    mdbSideNavCat: lib["mdbSideNavCat"],
    mdbSideNavItem: lib["mdbSideNavItem"],
    mdbIcon: lib["mdbIcon"],
    waves: lib["waves"],
    vSelect: vue_select_default.a
  },

  data: function data() {
    return {
      toggle: false,
      active: 0,
      elHeight: 0,
      windowHeight: 0,

      Patient: "",

      User: { name: "", duz: "" },
      UserList: "",

      mdSelectedDate: "",
      mdqDateValue: "",
      mdqDateField: "",
      Users: [],
      inputId: "SelectedUserInput",
      options: [],
      SelecUser: "Select User"
    };
  },


  computed: {
    vmUsers: function vmUsers() {
      return this.Users;
    }
  },

  mounted: function mounted() {
    var vm = this; // We need the local scope at mount time not at execute time

    eventBus.$on("mdbSelectPatient-Data", function (LUResult) {
      // console.log("SideNAV received mdbSelectPatient-Data event - ", LUResult.data)
      // let selUser = document.getElementsByClassName("vs__selected");
      // if (selUser[0] && selUser[0].innerText) {
      //   console.log("clear selected");
      //   selUser[0].innerText = "";
      // }

      this.Users = [""];

      if (LUResult.state) {
        // let selUser = document.getElementsByClassName("vs__selected");
        // if (selUser[0] && selUser[0].innerText) {
        //   console.log("clear selected");
        //   selUser[0].innerText = "";
        // }
        // selUser = document.getElementById("SelectedUserInput");
        // if (selUser && selUser.value) {
        //   selUser.value = "";
        // }


        vm.Patient = LUResult.data;
        console.log("vm.Patient = ", vm.Patient);
        // vm.PatientLookupResults = LUResult.data;
        // vm.mdSelectedUser = "";
        // const UsersList = LUResult.data.u[0].map(function(el) {
        var UsersList = LUResult.data.u.map(function (el) {
          return { label: el, text: el, value: el };
        });

        UsersList.sort(function (a, b) {
          // Use toUpperCase() to ignore character casing
          var textA = a.text.toUpperCase();
          var textB = b.text.toUpperCase();

          var comparison = 0;
          if (textA > textB) {
            comparison = 1;
          } else if (textA < textB) {
            comparison = -1;
          }
          return comparison;
        });

        setTimeout(function () {
          if (vm.$refs.SelectPatientBtn) {
            // console.log("Button should have focus")
            vm.$refs.SelectPatientBtn.$el.focus();
            vm.Users = UsersList;
          }
        }, 50);
      } else {
        console.log("SideNav - mdbSelectPatient-Data: ERROR - ", LUResult.data);
        vm.Users = [];
        eventBus.$emit("mdqp-list", { status: "Error", msg: LUResult.data });
      }
    });
  },


  methods: {
    UserSelected: function UserSelected(el) {
      if (el) {
        eventBus.$emit("SelectedUser", el.value);
      }
    },

    SelectPatient: function SelectPatient() {
      eventBus.$emit("show-select-patient", true);
    }
  },
  mixins: [lib["waves"]]
});
// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-dacc4178","hasScoped":true,"transformToRequire":{"video":["src","poster"],"source":"src","img":"src","image":"xlink:href"},"buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/SideNav.vue
var SideNav_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"deep-purple-skin"},[_c('mdb-side-nav',{ref:"sideNav",attrs:{"breakWidth":770,"OpenedFromOutside":_vm.toggle,"logo":'/assets/department-of-veterans-affairs-logo.svg',"logoAlt":'Logo for the Department of Veterans Affairs',"PatientLookupResults":_vm.PatientLookupResults,"mask":"strong","logoSn":"","sideNavClass":"sn-bg-4","fixed":""},on:{"update:OpenedFromOutside":function($event){_vm.toggle=$event},"update:opened-from-outside":function($event){_vm.toggle=$event}}},[_c('li',[_c('mdb-side-nav-nav',[_c('li',[_c('div',{staticClass:"text-center"},[_c('mdb-btn',{ref:"SelectPatientBtn",staticClass:"SelectPatient",attrs:{"color":"secondary","rounded":""},on:{"click":_vm.SelectPatient}},[_vm._v("Enter Patient Info")])],1),_vm._v(" "),(_vm.Patient.p)?_c('div',{staticClass:"form-group",on:{"click":_vm.wave}},[_c('div',{staticClass:"text-center"},[_vm._v("Patient")]),_vm._v(" "),_c('div',[_vm._v("Name: "),_c('span',{staticClass:"em"},[_vm._v(_vm._s(_vm.Patient.p))])]),_vm._v(" "),_c('div',[_vm._v("DOB: "),_c('span',{staticClass:"em"},[_vm._v(_vm._s(_vm.Patient.d))])]),_vm._v(" "),_c('div',[_vm._v("SSN: "),_c('span',{staticClass:"em"},[_vm._v(_vm._s(_vm.Patient.s))])]),_vm._v(" "),_c('br'),_vm._v(" "),_c('form',[(_vm.vmUsers.length > 0)?_c('label',{attrs:{"for":"SelectedUserInput"}},[_vm._v("User")]):_vm._e(),_vm._v(" "),_c('v-select',{attrs:{"id":"user","options":_vm.vmUsers,"clearable":false,"placeholder":_vm.SelecUser,"inputId":_vm.inputId},on:{"input":_vm.UserSelected}})],1)]):_vm._e()])])],1)])],1)}
var SideNav_staticRenderFns = []
var SideNav_esExports = { render: SideNav_render, staticRenderFns: SideNav_staticRenderFns }
/* harmony default export */ var selectortype_template_index_0_src_components_SideNav = (SideNav_esExports);
// CONCATENATED MODULE: ./src/components/SideNav.vue
function SideNav_injectStyle (ssrContext) {
  __webpack_require__("UgDZ")
}
var SideNav_normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var SideNav___vue_template_functional__ = false
/* styles */
var SideNav___vue_styles__ = SideNav_injectStyle
/* scopeId */
var SideNav___vue_scopeId__ = "data-v-dacc4178"
/* moduleIdentifier (server only) */
var SideNav___vue_module_identifier__ = null
var SideNav_Component = SideNav_normalizeComponent(
  components_SideNav,
  selectortype_template_index_0_src_components_SideNav,
  SideNav___vue_template_functional__,
  SideNav___vue_styles__,
  SideNav___vue_scopeId__,
  SideNav___vue_module_identifier__
)

/* harmony default export */ var src_components_SideNav = (SideNav_Component.exports);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/components/Navbar.vue
//
//
//
//
//
//



/* harmony default export */ var Navbar = ({
  name: 'Navbar',
  props: {
    page: {
      type: String
    }
  },

  components: {
    mdbNavbar: lib["mdbNavbar"],
    mdbNavbarBrand: lib["mdbNavbarBrand"],
    mdbNavbarNav: lib["mdbNavbarNav"],
    mdbIcon: lib["mdbIcon"]
  }
});
// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-82a210f8","hasScoped":true,"transformToRequire":{"video":["src","poster"],"source":"src","img":"src","image":"xlink:href"},"buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/Navbar.vue
var Navbar_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('mdb-navbar',{staticClass:"flexible-navbar",attrs:{"position":"top"}},[_c('h1',[_vm._v("Audit Query & And Retrieval Application")])])}
var Navbar_staticRenderFns = []
var Navbar_esExports = { render: Navbar_render, staticRenderFns: Navbar_staticRenderFns }
/* harmony default export */ var components_Navbar = (Navbar_esExports);
// CONCATENATED MODULE: ./src/components/Navbar.vue
function Navbar_injectStyle (ssrContext) {
  __webpack_require__("UfMJ")
}
var Navbar_normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var Navbar___vue_template_functional__ = false
/* styles */
var Navbar___vue_styles__ = Navbar_injectStyle
/* scopeId */
var Navbar___vue_scopeId__ = "data-v-82a210f8"
/* moduleIdentifier (server only) */
var Navbar___vue_module_identifier__ = null
var Navbar_Component = Navbar_normalizeComponent(
  Navbar,
  components_Navbar,
  Navbar___vue_template_functional__,
  Navbar___vue_styles__,
  Navbar___vue_scopeId__,
  Navbar___vue_module_identifier__
)

/* harmony default export */ var src_components_Navbar = (Navbar_Component.exports);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/App.vue
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ var App = ({
  name: 'App',
  components: {
    SideNav: src_components_SideNav,
    Navbar: src_components_Navbar
  },
  data: function data() {
    return {
      mdPatientQuery: '',
      mdSelectedPatient: {},

      mdUserQuery: '',
      mdSelectedUser: {},

      HomeTitle: '',
      PatientLookupResults: ''
    };
  },
  mounted: function mounted() {
    var vm = this; // We need the local scope at mount time not at execute time
    spinner.src = "/assets/spinner-yokratom.gif";

    eventBus.$on("mdbSelectPatient-Data", function (value) {
      // Data recieved from mdbSelectPatient component
      // that is now passed down to the SideNav (aka side-nav) component via the props at the top ^^
      if (value.state) {
        // console.log("App received mdbSelectPatient-Data event - ", value.data)
        vm.PatientLookupResults = value.data;
        vm.mdSelectedUser = "";
      }
    });
  }
});
// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-fa3d8b52","hasScoped":false,"transformToRequire":{"video":["src","poster"],"source":"src","img":"src","image":"xlink:href"},"buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/App.vue
var App_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{attrs:{"id":"app"}},[_c('navbar'),_vm._v(" "),_c('side-nav',{attrs:{"role":"navigation","aria-label":"Query"}}),_vm._v(" "),_c('div',{staticClass:"flexible-content"},[_c('main',[_c('div',[_c('router-view',{attrs:{"mdHomeTitle":_vm.HomeTitle,"mdPatientQuery":_vm.mdPatientQuery,"mdUserQuery":_vm.mdUserQuery,"mdSelectedPatient":_vm.mdSelectedPatient,"mdSelectedUser":_vm.mdSelectedUser,"PatientLookupResults":_vm.PatientLookupResults}})],1)])])],1)}
var App_staticRenderFns = []
var App_esExports = { render: App_render, staticRenderFns: App_staticRenderFns }
/* harmony default export */ var selectortype_template_index_0_src_App = (App_esExports);
// CONCATENATED MODULE: ./src/App.vue
function App_injectStyle (ssrContext) {
  __webpack_require__("+ku2")
}
var App_normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var App___vue_template_functional__ = false
/* styles */
var App___vue_styles__ = App_injectStyle
/* scopeId */
var App___vue_scopeId__ = null
/* moduleIdentifier (server only) */
var App___vue_module_identifier__ = null
var App_Component = App_normalizeComponent(
  App,
  selectortype_template_index_0_src_App,
  App___vue_template_functional__,
  App___vue_styles__,
  App___vue_scopeId__,
  App___vue_module_identifier__
)

/* harmony default export */ var src_App = (App_Component.exports);

// EXTERNAL MODULE: ./node_modules/vue-router/dist/vue-router.esm.js
var vue_router_esm = __webpack_require__("/ocq");

// EXTERNAL MODULE: ./node_modules/babel-runtime/core-js/json/stringify.js
var stringify = __webpack_require__("mvHQ");
var stringify_default = /*#__PURE__*/__webpack_require__.n(stringify);

// EXTERNAL MODULE: ./node_modules/babel-runtime/regenerator/index.js
var regenerator = __webpack_require__("Xxa5");
var regenerator_default = /*#__PURE__*/__webpack_require__.n(regenerator);

// EXTERNAL MODULE: ./node_modules/babel-runtime/helpers/asyncToGenerator.js
var asyncToGenerator = __webpack_require__("exGp");
var asyncToGenerator_default = /*#__PURE__*/__webpack_require__.n(asyncToGenerator);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/components/components/data_render2.vue
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




/* harmony default export */ var data_render2 = ({
  components: {
    mdbDatatable2: lib["mdbDatatable2"],
    mdbContainer: lib["mdbContainer"],
    mdbInput: lib["mdbInput"]
  },

  // params passed here by parent component
  props: {
    data: "",
    PatientLookupResults: "",
    selectedUser: ""
  },

  data: function data() {
    return {
      search: "",
      selected: null,
      columns: [],
      rows: []
    };
  },
  mounted: function mounted() {
    var _this = this;

    this.$nextTick(function () {
      // The native component does not have proper scoping
      // nor proper labeling of the first column checkboxes
      // This code rectifies that
      if (_this.$refs.table) {
        var table = _this.$refs.table.$el;

        var NextPage = table.getElementsByClassName("fa-chevron-right text-");
        var PrevPage = table.getElementsByClassName("fa-chevron-left text-");

        if (NextPage) {
          NextPage[0].parentNode.setAttribute("aria-label", "Next Page");
        }
        if (PrevPage) {
          PrevPage[0].parentNode.setAttribute("aria-label", "Previous Page");
        }

        var rowCells = table.getElementsByTagName("td");
        var headerCells = table.getElementsByTagName("th");
        rowCells.forEach(function (cell, idx, allCells) {
          cell.setAttribute("scope", "col");

          var ckBox = cell.getElementsByTagName("input");
          if (ckBox && ckBox.length > 0) {
            var ckID = "ck4_" + idx;
            ckBox[0].setAttribute("id", ckID);
            var mtLabel = cell.getElementsByTagName("label");
            if (mtLabel) {
              mtLabel[0].setAttribute("class", "sr-only");
              mtLabel[0].setAttribute("for", ckID);
              var fC = allCells[idx + 1].innerText;
              mtLabel[0].innerText = "Select Row for " + fC + " ";
            }
          }
        });
        headerCells.forEach(function (cell) {
          return cell.setAttribute("scope", "col");
        });
        rowCells[1].setAttribute("scope", "row"); // The second cell indicates the field that was changed which applies to the entire row.
      }
    });
  },


  methods: {
    selectRow: function selectRow(rowData) {
      eventBus.$emit("ShowAuditDetails", rowData);
    }
  }
});
// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-48542c88","hasScoped":false,"transformToRequire":{"video":["src","poster"],"source":"src","img":"src","image":"xlink:href"},"buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/components/data_render2.vue
var data_render2_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('mdb-container',[_c('div',{staticClass:"search"},[_c('label',[_vm._v("Search: "),_c('input',{directives:[{name:"model",rawName:"v-model",value:(_vm.search),expression:"search"}],staticClass:"mt-0",domProps:{"value":(_vm.search)},on:{"input":function($event){if($event.target.composing){ return; }_vm.search=$event.target.value}}})])]),_vm._v(" "),_c('mdb-datatable-2',{ref:"table",staticClass:"patient-user-metadata",attrs:{"data":_vm.data,"PatientLookupResults":_vm.PatientLookupResults,"selectedUser":_vm.selectedUser,"searching":{value: _vm.search, field: 'c'},"tfoot":false,"sorting":"","striped":"","bordered":"","fixed":"","scrollY":"","small":"","responsiveSm":"","maxHeight":"55vh","selectable":""},on:{"selected":_vm.selectRow},model:{value:(_vm.data),callback:function ($$v) {_vm.data=$$v},expression:"data"}})],1)}
var data_render2_staticRenderFns = []
var data_render2_esExports = { render: data_render2_render, staticRenderFns: data_render2_staticRenderFns }
/* harmony default export */ var components_data_render2 = (data_render2_esExports);
// CONCATENATED MODULE: ./src/components/components/data_render2.vue
function data_render2_injectStyle (ssrContext) {
  __webpack_require__("JW98")
}
var data_render2_normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var data_render2___vue_template_functional__ = false
/* styles */
var data_render2___vue_styles__ = data_render2_injectStyle
/* scopeId */
var data_render2___vue_scopeId__ = null
/* moduleIdentifier (server only) */
var data_render2___vue_module_identifier__ = null
var data_render2_Component = data_render2_normalizeComponent(
  data_render2,
  components_data_render2,
  data_render2___vue_template_functional__,
  data_render2___vue_styles__,
  data_render2___vue_scopeId__,
  data_render2___vue_module_identifier__
)

/* harmony default export */ var components_components_data_render2 = (data_render2_Component.exports);

// EXTERNAL MODULE: ./node_modules/babel-runtime/helpers/typeof.js
var helpers_typeof = __webpack_require__("pFYg");
var typeof_default = /*#__PURE__*/__webpack_require__.n(helpers_typeof);

// EXTERNAL MODULE: ./node_modules/vue-a11y-utils/dist/vue-a11y-utils.js
var vue_a11y_utils = __webpack_require__("E+le");

// EXTERNAL MODULE: ./src/serviceCall.js
var serviceCall = __webpack_require__("f6as");
var serviceCall_default = /*#__PURE__*/__webpack_require__.n(serviceCall);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/components/components/mdbModal.vue
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

var Modal = {
  props: {
    tag: {
      type: String,
      default: "div"
    },
    size: {
      type: String
    },
    side: {
      type: Boolean,
      default: false
    },
    position: {
      type: String
    },
    fullHeight: {
      type: Boolean,
      default: false
    },
    frame: {
      type: Boolean,
      default: false
    },
    removeBackdrop: {
      type: Boolean,
      default: false
    },
    centered: {
      type: Boolean,
      default: false
    },
    cascade: {
      type: Boolean,
      default: false
    },
    danger: {
      type: Boolean,
      default: false
    },
    info: {
      type: Boolean,
      default: false
    },
    success: {
      type: Boolean,
      default: false
    },
    warning: {
      type: Boolean,
      default: false
    },
    tabs: {
      type: Boolean,
      default: false
    },
    avatar: {
      type: Boolean,
      default: false
    },
    elegant: {
      type: Boolean,
      default: false
    },
    dark: {
      type: Boolean,
      default: false
    },
    bgSrc: {
      type: String,
      default: ''
    },
    direction: {
      type: String,
      default: 'top'
    },
    show: {
      type: Boolean,
      default: true
    },
    scrollable: {
      type: Boolean,
      default: false
    }
  },
  beforeMount: function beforeMount() {
    if (this.direction === 'right') {
      this.dialogTransform = 'translate(25%,0)';
    } else if (this.direction === 'bottom') {
      this.dialogTransform = 'translate(0,25%)';
    } else if (this.direction === 'left') {
      this.dialogTransform = 'translate(-25%,0)';
    }
  },
  data: function data() {
    return {
      dialogTransform: 'translate(0,-25%)'
    };
  },

  methods: {
    away: function away() {
      if (this.removeBackdrop) {
        return;
      }
      this.$emit('close', this);
    },
    enter: function enter(el) {
      el.style.opacity = 0;
      el.childNodes[0].style.transform = this.dialogTransform;
      this.$emit('show', this);
    },
    afterEnter: function afterEnter(el) {
      var _this = this;

      el.style.opacity = 1;
      el.childNodes[0].style.transform = 'translate(0,0)';
      setTimeout(function () {
        _this.$emit('shown', _this);
      }, 400);
    },
    beforeLeave: function beforeLeave(el) {
      this.$parent.$emit('hide', this);
      el.style.opacity = 0;
      el.childNodes[0].style.transform = this.dialogTransform;
    },
    afterLeave: function afterLeave() {
      this.$parent.$emit('hidden', this);
    }
  },
  computed: {
    wrapperClass: function wrapperClass() {
      return ['modal', this.removeBackdrop && 'modal-without-backdrop'];
    },
    dialogClass: function dialogClass() {
      return ['modal-dialog', this.size && 'modal-' + this.size, this.side && 'modal-side', this.fullHeight && 'modal-full-height', this.frame && 'modal-frame', this.position ? 'modal-' + this.position : '', this.centered && 'modal-dialog-centered', (this.cascade || this.tabs) && 'cascading-modal', this.danger && 'modal-notify modal-danger', this.info && 'modal-notify modal-info', this.success && 'modal-notify modal-success', this.warning && 'modal-notify modal-warning', this.avatar && 'modal-avatar cascading-modal', this.dark && 'form-dark', this.scrollable && 'modal-dialog-scrollable'];
    },
    contentClass: function contentClass() {
      return ['modal-content', this.tabs && 'modal-c-tabs', this.elegant && 'form-elegant', this.dark && 'card card-image'];
    },
    computedContentStyle: function computedContentStyle() {
      return this.bgSrc ? { 'background-image': 'url("' + this.bgSrc + '")' } : false;
    }
  }
};

/* harmony default export */ var mdbModal = (Modal);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-b055017a","hasScoped":true,"transformToRequire":{"video":["src","poster"],"source":"src","img":"src","image":"xlink:href"},"buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/components/mdbModal.vue
var mdbModal_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('transition',{attrs:{"name":"fade"},on:{"enter":_vm.enter,"after-enter":_vm.afterEnter,"before-leave":_vm.beforeLeave,"after-leave":_vm.afterLeave}},[(_vm.show)?_c(_vm.tag,{tag:"component",class:_vm.wrapperClass,attrs:{"tabindex":"0"},on:{"keyup":function($event){if(!$event.type.indexOf('key')&&_vm._k($event.keyCode,"esc",27,$event.key,["Esc","Escape"])){ return null; }return _vm.away($event)}}},[_c('div',{class:_vm.dialogClass,attrs:{"role":"document"}},[_c('div',{class:_vm.contentClass,style:(_vm.computedContentStyle)},[_vm._t("default")],2)])]):_vm._e()],1)}
var mdbModal_staticRenderFns = []
var mdbModal_esExports = { render: mdbModal_render, staticRenderFns: mdbModal_staticRenderFns }
/* harmony default export */ var components_mdbModal = (mdbModal_esExports);
// CONCATENATED MODULE: ./src/components/components/mdbModal.vue
function mdbModal_injectStyle (ssrContext) {
  __webpack_require__("U5C1")
}
var mdbModal_normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var mdbModal___vue_template_functional__ = false
/* styles */
var mdbModal___vue_styles__ = mdbModal_injectStyle
/* scopeId */
var mdbModal___vue_scopeId__ = "data-v-b055017a"
/* moduleIdentifier (server only) */
var mdbModal___vue_module_identifier__ = null
var mdbModal_Component = mdbModal_normalizeComponent(
  mdbModal,
  components_mdbModal,
  mdbModal___vue_template_functional__,
  mdbModal___vue_styles__,
  mdbModal___vue_scopeId__,
  mdbModal___vue_module_identifier__
)

/* harmony default export */ var components_components_mdbModal = (mdbModal_Component.exports);

// EXTERNAL MODULE: ./node_modules/axios/index.js
var axios = __webpack_require__("mtWM");
var axios_default = /*#__PURE__*/__webpack_require__.n(axios);

// EXTERNAL MODULE: ./node_modules/lodash/lodash.js
var lodash = __webpack_require__("M4fF");
var lodash_default = /*#__PURE__*/__webpack_require__.n(lodash);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/components/components/mdbSelectPatient.vue



//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//












var APIBase4P = process.env.VUE_APP_API_BASE;
var httpHeaders = {
  "Accept": "application/json"
};

/* harmony default export */ var mdbSelectPatient = ({
  components: {
    mdbContainer: lib["mdbContainer"],
    mdbBtn: lib["mdbBtn"],
    mdbModal: components_components_mdbModal,
    mdbModalHeader: lib["mdbModalHeader"],
    mdbModalBody: lib["mdbModalBody"],
    mdbModalFooter: lib["mdbModalFooter"],
    mdbInput: lib["mdbInput"],
    mdbModalTitle: lib["mdbModalTitle"],
    VueFocusTrap: vue_a11y_utils["a" /* VueFocusTrap */]
  },
  data: function data() {
    return {
      showSelectedPatientDlg: false,
      attemptSubmit: false,
      name: "",
      dob: "",
      ssn: ""
    };
  },

  computed: {
    missingName: function missingName() {
      return !this.validateName(this.name);
    },
    missingDoB: function missingDoB() {
      return !this.validateDoB(this.dob);
    },
    missingSsn: function missingSsn() {
      return !this.validateSsn(this.ssn);
    }
  },
  watch: {
    dob: function dob(value) {
      this.validateDoB(value);
    },
    name: function name(value) {
      this.validateName(value);
    },
    ssn: function ssn(value) {
      this.validateSsn(value);
    }
  },
  mounted: function mounted() {
    var vm = this; // We need the local scope at mount time not at execute time
    eventBus.$on("show-select-patient", function (message) {
      // Open the Patient Selection dialog
      vm.showSelectedPatientDlg = true;
      vm.attemptSubmit = false;
      vm.name = "";
      vm.dob = "";
      vm.ssn = "";
      setTimeout(function () {
        if (vm.$refs.InputPatientName) {
          var dialog = vm.$refs.dialog;
          if (dialog) {
            dialog.open();
          }
        }
      }, 400);
    });
  },

  methods: {
    hideSelectPatientDlg: function hideSelectPatientDlg() {
      // console.log("hideSelectPatientDlg()");
      var dialog = this.$refs.dialog;
      if (dialog) {
        // console.log("Close the dialog");
        dialog.close(true);
      }
      this.showSelectedPatientDlg = false;
    },
    open: function open() {
      var vm = this;
      setTimeout(function () {
        vm.goFirst();
      }, 400);
    },
    goFirst: function goFirst() {
      this.$refs.InputPatientName.focus();
    },
    goLast: function goLast() {
      this.$refs.Search.focus();
    },

    validateName: function validateName(value) {
      var nameValidator = /^[a-zA-Z]+(([',. -][a-zA-Z ])?[a-zA-Z]*)*$/;
      var safeSearch4 = lodash_default.a.escapeRegExp(value);
      var validName = nameValidator.test(safeSearch4);

      return validName && value.length >= 5;
    },
    validateDoB: function validateDoB(value) {
      return this.isValidDate(value);
    },
    validateSsn: function validateSsn(value) {
      var ssnValidator = /^\d{9}$|^\d{9}P$/;
      var safeSearch4 = lodash_default.a.escapeRegExp(value);
      var validSSN = ssnValidator.test(safeSearch4);
      return validSSN;
    },
    validateForm: function () {
      var _ref = asyncToGenerator_default()( /*#__PURE__*/regenerator_default.a.mark(function _callee(event) {
        var haveDob, haveSsn, haveName, ValidInput, queryParams, queryUri, cDob, clearSelect, theResponse, thePatient, y, m, d, s1, s2, s3;
        return regenerator_default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                haveDob = this.validateDoB(this.dob);
                haveSsn = this.validateSsn(this.ssn);
                haveName = this.validateName(this.name);
                ValidInput = haveName && (haveDob || haveSsn);
                queryParams = { type: "patient" };
                queryUri =  + "patient?p=";

                if (haveName) {
                  queryParams.pName = this.name;
                  queryUri += this.name;
                }
                if (haveDob) {
                  cDob = this.dob.split("/");

                  queryParams.dob = this.dob;
                  queryUri = queryUri + "&d=" + cDob[2] + cDob[0] + cDob[1];
                }
                if (haveSsn) {
                  queryParams.ssn = this.ssn;
                  queryUri = queryUri + "&s=" + this.ssn;
                }

                if (!ValidInput) {
                  _context.next = 29;
                  break;
                }

                _context.prev = 10;
                clearSelect = document.getElementsByClassName("vs__clear");

                if (clearSelect.length > 0) {
                  clearSelect[0].click(); // Clear the "Select User" input field
                }
                queryUri = serviceCall_default.a.genQuery(queryParams);
                console.log("mdbSelectPatient - qParams - ", queryParams);
                console.log("mdbSelectPatient - Query: " + queryUri + "\nHeaders: ", httpHeaders);
                _context.next = 18;
                return axios_default.a.get(queryUri, {
                  headers: httpHeaders
                }).catch(function (err) {
                  throw new Error("Empty state axios call FAILED - " + err);
                });

              case 18:
                theResponse = _context.sent;

                console.log("Response from call - ", theResponse);

                if (theResponse.status === 204) {
                  console.log("No Data Returned");
                  console.log("mdbSelectPatient.vue - mdqp-list - 204");
                  console.log("mdbSelectPatient.vue - mdqp-list - No Data - get ", queryUri);
                  eventBus.$emit("mdqp-list", {
                    status: "No Data",
                    msg: {
                      name: this.name,
                      dob: this.dob,
                      ssn: this.ssn
                    }
                  });
                } else {
                  thePatient = theResponse.data;

                  console.log("The Response - Patient ", thePatient);
                  console.log("what type - ", typeof thePatient === "undefined" ? "undefined" : typeof_default()(thePatient));
                  console.log("The Response - Patient DOB ", thePatient.d);

                  if (thePatient) {
                    y = thePatient.d.substr(0, 4);
                    m = thePatient.d.substr(4, 2);
                    d = thePatient.d.substr(6, 2);
                    s1 = thePatient.s.substr(0, 3);
                    s2 = thePatient.s.substr(3, 2);
                    s3 = thePatient.s.substr(5, 4);

                    thePatient.key = thePatient.p + "-" + thePatient.s + "-" + thePatient.d;
                    thePatient.d = m + "/" + d + "/" + y;
                    thePatient.s = s1 + "-" + s2 + "-" + s3;
                    console.log("The Patient Return Data - ", thePatient);
                    eventBus.$emit("mdqp-list", {
                      status: "Patient Search Complete",
                      msg: ""
                    });
                    eventBus.$emit("mdbSelectPatient-Data", {
                      state: true,
                      data: thePatient
                    }); // Send an event (mdbSelectPatient-Data) up to the App component with data.
                  } else {
                    console.log("No Patient");
                  }
                }
                _context.next = 26;
                break;

              case 23:
                _context.prev = 23;
                _context.t0 = _context["catch"](10);

                console.log("mdbSelectPatient.vue - mdqp-list - validateForm - Data Retrieval fail ", _context.t0);

              case 26:
                this.hideSelectPatientDlg();
                _context.next = 31;
                break;

              case 29:
                console.log("mdbSelectPatient.vue - mdqp-list - validateForm - Name Validation Fail");
                this.attemptSubmit = true;

              case 31:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this, [[10, 23]]);
      }));

      function validateForm(_x) {
        return _ref.apply(this, arguments);
      }

      return validateForm;
    }(),
    isNumber: function isNumber($event) {
      if ($event.charCode === 0 || /\d/.test(String.fromCharCode($event.charCode))) {
        return true;
      }
      $event.preventDefault();
    },
    isNumberOrSlash: function isNumberOrSlash($event) {
      if ($event.charCode === 0 || /\d/.test(String.fromCharCode($event.charCode)) || /\//.test(String.fromCharCode($event.charCode))) {
        return true;
      }
      $event.preventDefault();
    },
    isValidDate: function isValidDate(value) {
      var inputText = this.dob;
      var dateformat = /^[01][0-9]\/[0123][0-9]\/\d{4}$/;
      if (inputText.length === 10) {
        if (inputText.match(dateformat)) {
          var ListofDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
          var opera1 = inputText.split("/");
          var lopera1 = opera1.length;
          var pdate = void 0;
          var mm = void 0;
          var dd = void 0;
          var yy = void 0;
          if (lopera1 > 1) {
            pdate = inputText.split("/");
            if (pdate && pdate.length > 2) {
              mm = parseInt(pdate[0]);
              dd = parseInt(pdate[1]);
              yy = parseInt(pdate[2]);
            }
          }
          if (mm === 1 || mm > 2) {
            if (dd > ListofDays[mm - 1]) {
              return false;
            }
          }
          if (mm === 2) {
            var lyear = false;
            if (!(yy % 4) && yy % 100 || !(yy % 400)) {
              lyear = true;
            }
            if (lyear === false && dd >= 29) {
              return false;
            }
            if (lyear === true && dd > 29) {
              return false;
            }
          }
        } else {
          return false;
        }
      } else {
        return false;
      }
      return true;
    }
  }
});
// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-3592cef3","hasScoped":false,"transformToRequire":{"video":["src","poster"],"source":"src","img":"src","image":"xlink:href"},"buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/components/mdbSelectPatient.vue
var mdbSelectPatient_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('VueFocusTrap',{ref:"dialog",on:{"open":_vm.open,"gofirst":_vm.goFirst,"golast":_vm.goLast}},[_c('section',[_c('mdb-modal',{ref:"modal",attrs:{"centered":"","show":_vm.showSelectedPatientDlg},on:{"close":function($event){return _vm.hideSelectPatientDlg()}}},[_c('mdb-modal-header',{staticClass:"text-center"},[_c('mdb-modal-title',{staticClass:"w-100",attrs:{"tag":"h2","bold":""}},[_vm._v("Enter Patient Information")])],1),_vm._v(" "),_c('mdb-modal-body',{staticClass:"text-right"},[_c('p',{staticClass:"sr-only"},[_vm._v("Fields marked with an asterisk are required")]),_vm._v(" "),_c('form',{attrs:{"id":"SelectPatient"}},[_c('input',{directives:[{name:"model",rawName:"v-model",value:(_vm.name),expression:"name"}],ref:"InputPatientName",staticStyle:{"margin-bottom":"2px","margin-top":"8px"},attrs:{"type":"text","required":"","autocomplete":"off","id":"name"},domProps:{"value":(_vm.name)},on:{"input":function($event){if($event.target.composing){ return; }_vm.name=$event.target.value}}}),_vm._v(" "),_c('label',{attrs:{"for":"name"}},[_vm._v("Patient Full Name (Last,First Middle): "),_c('span',{staticStyle:{"font-size":"larger","padding":"0 5px 0 0"}},[_vm._v("*")]),_c('span',{staticClass:"sr-only"},[_vm._v("Required")])]),_vm._v(" "),(_vm.attemptSubmit && _vm.missingName)?_c('p',{staticClass:"err"},[_vm._v("Enter a patients Full Name (Last,First Middle)")]):_vm._e(),_vm._v(" "),_c('fieldset',[_c('legend',[_vm._v("Date of Birth "),_c('span',{staticStyle:{"font-weight":"bold"}},[_vm._v("OR")]),_vm._v(" Social Security Number are required")]),_vm._v(" "),_c('input',{directives:[{name:"model",rawName:"v-model",value:(_vm.dob),expression:"dob"}],staticStyle:{"margin-bottom":"2px","margin-top":"1px"},attrs:{"type":"text","autocomplete":"off","maxlength":"10","id":"dob"},domProps:{"value":(_vm.dob)},on:{"keypress":function($event){return _vm.isNumberOrSlash($event)},"input":function($event){if($event.target.composing){ return; }_vm.dob=$event.target.value}}}),_vm._v(" "),_c('label',{attrs:{"for":"dob"}},[_vm._v("Date of Birth (MM/DD/YYYY): ")]),_vm._v(" "),(_vm.attemptSubmit && _vm.missingDoB)?_c('p',{staticClass:"err"},[_vm._v("Enter Patient\"s Date of Birth (MM/DD/YYYY)")]):_vm._e(),_vm._v(" "),_c('hr'),_vm._v(" "),_c('input',{directives:[{name:"model",rawName:"v-model",value:(_vm.ssn),expression:"ssn"}],staticStyle:{"margin-bottom":"2px","margin-top":"1px"},attrs:{"type":"text","autocomplete":"off","id":"ssn","maxlength":"9"},domProps:{"value":(_vm.ssn)},on:{"keypress":function($event){return _vm.isNumber($event)},"input":function($event){if($event.target.composing){ return; }_vm.ssn=$event.target.value}}}),_vm._v(" "),_c('label',{attrs:{"for":"ssn"}},[_vm._v("Social Security Number (#########): ")]),_vm._v(" "),(_vm.attemptSubmit && _vm.missingSsn)?_c('p',{staticClass:"err"},[_vm._v("Enter Patient\"s Social Security Number (no dashes or spaces)")]):_vm._e()]),_vm._v(" "),_c('mdb-btn',{ref:"Search",attrs:{"center":"","type":"button","color":"secondary","rounded":""},nativeOn:{"click":function($event){return _vm.validateForm($event)}}},[_vm._v("Search for Patient")])],1)])],1)],1)])}
var mdbSelectPatient_staticRenderFns = []
var mdbSelectPatient_esExports = { render: mdbSelectPatient_render, staticRenderFns: mdbSelectPatient_staticRenderFns }
/* harmony default export */ var components_mdbSelectPatient = (mdbSelectPatient_esExports);
// CONCATENATED MODULE: ./src/components/components/mdbSelectPatient.vue
function mdbSelectPatient_injectStyle (ssrContext) {
  __webpack_require__("pqYQ")
}
var mdbSelectPatient_normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var mdbSelectPatient___vue_template_functional__ = false
/* styles */
var mdbSelectPatient___vue_styles__ = mdbSelectPatient_injectStyle
/* scopeId */
var mdbSelectPatient___vue_scopeId__ = null
/* moduleIdentifier (server only) */
var mdbSelectPatient___vue_module_identifier__ = null
var mdbSelectPatient_Component = mdbSelectPatient_normalizeComponent(
  mdbSelectPatient,
  components_mdbSelectPatient,
  mdbSelectPatient___vue_template_functional__,
  mdbSelectPatient___vue_styles__,
  mdbSelectPatient___vue_scopeId__,
  mdbSelectPatient___vue_module_identifier__
)

/* harmony default export */ var components_components_mdbSelectPatient = (mdbSelectPatient_Component.exports);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/components/components/mdbAudit.vue
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//






var ShowAuditRecord = {
  props: {
    showAuditDetails: false,
    auditData: {}
  },

  data: function data() {
    return {
      auditRecord: {},
      ExtraData: false,
      dialogOpen: false
    };
  },


  name: "MDQAudit",
  components: { eventBus: eventBus, mdbBtn: lib["mdbBtn"], mdbModal: components_components_mdbModal, mdbModalHeader: lib["mdbModalHeader"], mdbModalTitle: lib["mdbModalTitle"], mdbModalBody: lib["mdbModalBody"], mdbModalFooter: lib["mdbModalFooter"], VueFocusTrap: vue_a11y_utils["a" /* VueFocusTrap */] },

  updated: function updated() {
    console.log("mdbAudit is updated - ", this.showAuditDetails);
    if (this.showAuditDetails) {
      this.$nextTick(function () {
        var dialog = this.$refs.dialog;
        console.log("Opening the dialog ");
        if (dialog && !this.dialogOpen) {
          console.log("dialog was NOT open");
          this.dialogOpen = true;
          dialog.open();
        }
      });
    }
  },


  methods: {
    open: function open() {
      var vm = this;
      setTimeout(function () {
        vm.goFirst();
      }, 400);
    },
    goFirst: function goFirst() {
      this.$refs.closePUBtn1.$el.focus();
    },
    goLast: function goLast() {
      this.$refs.closePUBtn1.$el.focus();
    },
    getAuditRecordDT: function getAuditRecordDT() {
      console.log("getAuditRecordDT() - Entry");
      if (this.auditData.auditRecord && this.auditData.auditRecord.HEADER) {
        console.log("getAuditRecordDT() We have a header");
        var x = this.auditData.auditRecord.HEADER.DateTime;
        if (!x) {
          return this.auditData.auditRecord.HEADER;
        }

        var s = x.split("-");
        var d = s[0] + "000000"; // Date and time, padding 0's on the end because sometimes VistA sends a "short" date string
        var z = s[1]; // Zulu offset

        var iso = d.substring(0, 4) + "-" + d.substring(4, 6) + "-" + d.substring(6, 8) + "T" + d.substring(8, 10) + ":" + d.substring(10, 12) + ":" + d.substring(12, 14);
        iso += "-" + z;
        return new Date(iso);
      }
    },
    closePU: function closePU() {
      var dialog = this.$refs.dialog;
      if (dialog) {
        dialog.close(true);
        this.dialogOpen = false;
      }
      eventBus.$emit("hide", this);
    }
  }
};
/* harmony default export */ var mdbAudit = (ShowAuditRecord);

// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-43ab8696","hasScoped":false,"transformToRequire":{"video":["src","poster"],"source":"src","img":"src","image":"xlink:href"},"buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/components/mdbAudit.vue
var mdbAudit_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('VueFocusTrap',{ref:"dialog",on:{"open":_vm.open,"gofirst":_vm.goFirst,"golast":_vm.goLast}},[_c('section',[(_vm.showAuditDetails)?_c('mdb-modal',{ref:"modal",attrs:{"tabindex":"9999","centered":"","auditData":_vm.auditData},on:{"close":function($event){return _vm.closePU()}}},[_c('mdb-modal-header',{staticClass:"text-center"},[_c('mdb-modal-title',{staticClass:"w-100",attrs:{"tag":"h2","bold":""}},[_vm._v("Audit Record")])],1),_vm._v(" "),_c('mdb-modal-body',[(_vm.auditData)?_c('div',[(!_vm.auditData.status)?_c('div',[_vm._v("\n            No record found for "+_vm._s(_vm.auditData.msg)+"\n          ")]):_vm._e(),_vm._v(" "),(_vm.auditData.status && _vm.auditData.auditRecord.HEADER && _vm.auditData.auditRecord.SCHEMA)?_c('div',[_c('p',{staticClass:"sr-only",attrs:{"id":"Audit_Table_Desc"}},[_vm._v("Audit Record Details")]),_vm._v(" "),_c('table',{attrs:{"aria-describedby":"Audit_Table_Desc","xRef":"data"}},[_c('caption',{staticClass:"sr-only"},[_vm._v("Display audit record header data for selected patient/user")]),_vm._v(" "),_c('tr',[_c('th',{attrs:{"scope":"row","colspan":"2"}},[_c('h3',[_vm._v("Audit Header")])])]),_vm._v(" "),_c('tr',[_c('th',{attrs:{"scope":"row"}},[_vm._v("Date / Time:")]),_c('td',[_vm._v(_vm._s(_vm.getAuditRecordDT()))])]),_vm._v(" "),_c('tr',[_c('th',{attrs:{"scope":"row"}},[_vm._v("Site / Station #:")]),_c('td',[_vm._v(_vm._s(_vm.auditData.auditRecord.HEADER.Location.Site)+" / "+_vm._s(_vm.auditData.auditRecord.HEADER.Location.StationNumber))])]),_vm._v(" "),_c('tr',[_c('th',{attrs:{"scope":"row"}},[_vm._v("Patient Name:")]),_c('td',[_c('strong',[_vm._v(_vm._s(_vm.auditData.auditRecord.HEADER.Patient.PatientName))])])]),_vm._v(" "),_c('tr',[_c('th',{attrs:{"scope":"row"}},[_vm._v("Patient MVI / DFN:")]),_c('td',[_vm._v(_vm._s(_vm.auditData.auditRecord.HEADER.Patient.MVI)+" / "+_vm._s(_vm.auditData.auditRecord.HEADER.Patient.DFN)+" ")])]),_vm._v(" "),_c('tr',[_c('th',{attrs:{"scope":"row"}},[_vm._v("User Name:")]),_c('td',[_c('strong',[_vm._v(_vm._s(_vm.auditData.auditRecord.HEADER.User.UserName))])])]),_vm._v(" "),_c('tr',[_c('th',{attrs:{"scope":"row"}},[_vm._v("User Title / DUZ / UID:")]),_c('td',[_vm._v(_vm._s(_vm.auditData.auditRecord.HEADER.User.Title)+" / "+_vm._s(_vm.auditData.auditRecord.HEADER.User.DUZ)+" / "+_vm._s(_vm.auditData.auditRecord.HEADER.User.UID))])]),_vm._v(" "),_c('tr',[_c('th',{attrs:{"scope":"row"}},[_vm._v("Year / Week #:")]),_c('td',[_vm._v(_vm._s(_vm.auditData.auditRecord.HEADER.Year)+" / "+_vm._s(_vm.auditData.auditRecord.HEADER.Week))])]),_vm._v(" "),_c('tr',[_c('th',{attrs:{"scope":"row"}},[_vm._v("Request Type:")]),_c('td',[_vm._v(_vm._s(_vm.auditData.auditRecord.HEADER.RequestType)+" ")])]),_vm._v(" "),(_vm.ExtraData)?_c('tr',[_c('th',{attrs:{"scope":"row"}},[_vm._v("Type of Record:")]),_c('td',[_vm._v(_vm._s(_vm.auditData.auditRecord.HEADER.SchemaType))])]):_vm._e()]),_vm._v(" "),_c('table',{attrs:{"aria-describedby":"Audit_Table_Desc","xRef":"data"}},[_c('caption',{staticClass:"sr-only"},[_vm._v("Display audit record data for selected patient/user")]),_vm._v(" "),_c('tr',[_c('th',{attrs:{"scope":"row","colspan":"2"}},[_c('h3',[_vm._v("Audit Data")])])]),_vm._v(" "),_c('tr',[_c('th',{attrs:{"scope":"row"}},[_vm._v("Field Name:")]),_c('td',[_vm._v(_vm._s(_vm.auditData.auditRecord.SCHEMA["FIELD NAME"]))])]),_vm._v(" "),(_vm.ExtraData)?_c('tr',[_c('th',{attrs:{"scope":"row"}},[_vm._v("Menu Option Used:")]),_c('td',[_vm._v(_vm._s(_vm.auditData.auditRecord.SCHEMA["MENU OPTION USED"]))])]):_vm._e(),_vm._v(" "),_c('tr',[_c('th',{attrs:{"scope":"row"}},[_vm._v("Old Value:")]),_c('td',[_vm._v(_vm._s(_vm.auditData.auditRecord.SCHEMA["OLD VALUE"]))])]),_vm._v(" "),_c('tr',[_c('th',{attrs:{"scope":"row"}},[_vm._v("New Value:")]),_c('td',[_vm._v(_vm._s(_vm.auditData.auditRecord.SCHEMA["NEW VALUE"]))])]),_vm._v(" "),(_vm.ExtraData)?_c('tr',[_c('th',{attrs:{"scope":"row"}},[_vm._v("Record Added:")]),_c('td',[_vm._v(_vm._s(_vm.auditData.auditRecord.SCHEMA["RECORD ADDED"]))])]):_vm._e(),_vm._v(" "),(_vm.ExtraData)?_c('tr',[_c('th',{attrs:{"scope":"row"}},[_vm._v("Protocol or Option Used:")]),_c('td',[_vm._v(_vm._s(_vm.auditData.auditRecord.SCHEMA["PROTOCOL or OPTION USED"]))])]):_vm._e(),_vm._v(" "),(_vm.ExtraData)?_c('tr',[_c('th',{attrs:{"scope":"row"}},[_vm._v("File Number:")]),_c('td',[_vm._v(_vm._s(_vm.auditData.auditRecord.SCHEMA["FILE NUMBER"]))])]):_vm._e(),_vm._v(" "),(_vm.ExtraData)?_c('tr',[_c('th',{attrs:{"scope":"row"}},[_vm._v("File Name:")]),_c('td',[_vm._v(_vm._s(_vm.auditData.auditRecord.SCHEMA["FILE NAME"]))])]):_vm._e()])]):_vm._e()]):_vm._e()]),_vm._v(" "),_c('mdb-modal-footer',[_c('mdb-btn',{ref:"closePUBtn1",attrs:{"center":"","rounded":"","color":"secondary"},nativeOn:{"click":function($event){return _vm.closePU()}}},[_vm._v("Close")])],1)],1):_vm._e()],1)])}
var mdbAudit_staticRenderFns = []
var mdbAudit_esExports = { render: mdbAudit_render, staticRenderFns: mdbAudit_staticRenderFns }
/* harmony default export */ var components_mdbAudit = (mdbAudit_esExports);
// CONCATENATED MODULE: ./src/components/components/mdbAudit.vue
function mdbAudit_injectStyle (ssrContext) {
  __webpack_require__("AR0u")
}
var mdbAudit_normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var mdbAudit___vue_template_functional__ = false
/* styles */
var mdbAudit___vue_styles__ = mdbAudit_injectStyle
/* scopeId */
var mdbAudit___vue_scopeId__ = null
/* moduleIdentifier (server only) */
var mdbAudit___vue_module_identifier__ = null
var mdbAudit_Component = mdbAudit_normalizeComponent(
  mdbAudit,
  components_mdbAudit,
  mdbAudit___vue_template_functional__,
  mdbAudit___vue_styles__,
  mdbAudit___vue_scopeId__,
  mdbAudit___vue_module_identifier__
)

/* harmony default export */ var components_components_mdbAudit = (mdbAudit_Component.exports);

// EXTERNAL MODULE: ./node_modules/moment/moment.js
var moment = __webpack_require__("PJh5");
var moment_default = /*#__PURE__*/__webpack_require__.n(moment);

// CONCATENATED MODULE: ./node_modules/babel-loader/lib!./node_modules/vue-loader/lib/selector.js?type=script&index=0!./src/components/dashboards/home.vue



//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//












var home_httpHeaders = {
  "Accept": "application/json"
};

console.log("HOME: httpHeaders = ", home_httpHeaders);

/* harmony default export */ var home = ({
  props: {
    mdHomeTitle: "",
    mdPatientQuery: "",
    mdUserQuery: {},
    mdSelectedPatient: "",
    mdSelectedUser: "",
    PatientLookupResults: {}
  },
  name: "Home",
  components: {
    dataTable: components_components_data_render2,
    mdbSelectPatient: components_components_mdbSelectPatient,
    mdbShowAuditDetails: components_components_mdbAudit,
    mdbContainer: lib["mdbContainer"],
    mdbCard: lib["mdbCard"],
    mdbCardBody: lib["mdbCardBody"],
    vSelect: vue_select_default.a
  },

  data: function data() {
    return {
      httpHeaders: {
        "Accept": "application/json"
      },
      Error: "",
      showWaiting: true,
      initialShowWaiting: true,
      auditDetails: {},
      renderDataTableComponent: false,
      pageTitle: "",
      selectedUser: "",
      patientSearchData: {},
      // mdbID: "",
      options: [],
      showAuditDetails: false,
      auditData: {}
    };
  },


  computed: {
    State: function State() {
      if (this.pageTitle === "") {
        return "";
      } else if (this.pageTitle === "Start Search") {
        return this.pageTitle;
      } else if (this.pageTitle === "Searching") {
        // Start searching for specified patient
        return this.pageTitle;
      } else if (this.pageTitle === "Patient Search Complete") {
        return this.pageTitle;
      } else if (this.pageTitle === "Complete") {
        return this.pageTitle;
      } else if (this.pageTitle === "No Data") {
        return this.pageTitle;
      } else if (this.pageTitle === "User Selected") {
        return this.pageTitle;
      } else if (this.pageTitle === "Error") {
        return this.pageTitle;
      }
      console.log("State View Unknown message received ", this.pageTitle);
      return "";
    }
  },

  mounted: function mounted() {
    var vm = this; // We need the local scope at mount time not at execute time

    // console.log("Mount - Initial Spinner - ", this.showWaiting)

    setTimeout(function () {
      // console.log("Initial Spinner")
      vm.showWaiting = false;
      vm.initialShowWaiting = false;
    }, 2000);

    // Message sent from Select Patient dialog
    // Possible states are : "No Data", "Start Search", "Searching", "Complete"
    eventBus.$on("mdqp-list", function () {
      var _ref = asyncToGenerator_default()( /*#__PURE__*/regenerator_default.a.mark(function _callee(message) {
        return regenerator_default.a.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                console.log("Home.vue received mdqp-list - ", message);
                vm.pageTitle = message.status;
                // vm.hideSpinner();

                // if (message.status !== "Searching") {
                //   vm.hideSpinner();
                // }
                if (message.status === "Error") {
                  vm.Error = message.msg;
                  vm.hideSpinner();
                } else {
                  vm.Error = "";
                }
                if (message.status === "No Data") {
                  vm.patientSearchData = message.msg;
                  vm.hideSpinner();
                }
                if (message.status === "Patient Search Complete") {
                  vm.selectedUser = "";
                  vm.hideSpinner();
                }

              case 5:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this);
      }));

      return function (_x) {
        return _ref.apply(this, arguments);
      };
    }());

    eventBus.$on("wait-for-search", function () {
      var _ref2 = asyncToGenerator_default()( /*#__PURE__*/regenerator_default.a.mark(function _callee2(state) {
        return regenerator_default.a.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                if (state) {
                  vm.showSpinner();
                } else {
                  vm.hideSpinner();
                }

              case 1:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2, this);
      }));

      return function (_x2) {
        return _ref2.apply(this, arguments);
      };
    }());

    eventBus.$on("SelectedUser", function (theUser) {
      // console.log("Who called SelectedUser? - ", theUser)
      vm.pageTitle = "User Selected";
      vm.selectedUser = theUser;
      vm.forceRerender(false); // Don't render the data table until data is available
    });

    // Event passed when selecting row in data table (data_render2 component), the MetaData record contained in the table is passed.
    eventBus.$on("ShowAuditDetails", function () {
      var _ref3 = asyncToGenerator_default()( /*#__PURE__*/regenerator_default.a.mark(function _callee3(mdRecord) {
        var rslt;
        return regenerator_default.a.wrap(function _callee3$(_context3) {
          while (1) {
            switch (_context3.prev = _context3.next) {
              case 0:
                if (!mdRecord) {
                  _context3.next = 6;
                  break;
                }

                _context3.next = 3;
                return vm.getAuditData(mdRecord);

              case 3:
                rslt = _context3.sent;

                vm.showAuditDetails = true;

                if (rslt.status === 200) {
                  vm.auditData.status = true;
                  // OLDBUCK,DUENNA
                  // -265243174-19791009
                  vm.auditData.auditRecord = rslt.data;
                  vm.auditData.msg = "";
                } else {
                  vm.auditData.status = false;
                  vm.auditData.msg = "patient: " + mdRecord.p.split("-")[0] + " \nUser: " + mdRecord.u.split("-")[0];
                }

              case 6:
              case "end":
                return _context3.stop();
            }
          }
        }, _callee3, this);
      }));

      return function (_x3) {
        return _ref3.apply(this, arguments);
      };
    }());

    eventBus.$on("closeAuditRecord", function () {
      if (vm.$refs.SelectMetadataRecord) {
        // console.log("Set focus in Data Table - ", vm.mdbID)
        var theSelected = document.querySelector(".patient-user-metadata tbody td input[value=true]");
        theSelected.focus();
      }
    });

    eventBus.$on("hide", function (ob) {
      // Then set focus on some element within the modal to allow for "esc" to close it
      // console.log("Hide Audit Record")
      if (ob.showAuditDetails) {
        vm.showAuditDetails = false;
      }
    });
  },


  methods: {
    hideSpinner: function hideSpinner() {
      var vm = this;
      // console.log("Hide spinner - (delay) ", false, " current - ", this.showWaiting);
      setTimeout(function () {
        vm.showWaiting = false;
        vm.initialShowWaiting = false;
      }, 400);
    },
    showSpinner: function showSpinner() {
      // console.log("Show spinner - (never delay) ", true);
      this.showWaiting = true;
    },
    forceRerender: function forceRerender(flag) {
      var _this = this;

      // This is used to force the datatable to render fresh data as soon as it comes in
      // Remove my-component from the DOM
      this.renderDataTableComponent = false;

      if (flag) {
        this.$nextTick(function () {
          // Add the component back in
          _this.renderDataTableComponent = true;
        });
      }
    },
    getAuditData: function getAuditData(mdRecord) {
      var _this2 = this;

      return asyncToGenerator_default()( /*#__PURE__*/regenerator_default.a.mark(function _callee4() {
        var vm, queryParams, queryUri, rslt, errState;
        return regenerator_default.a.wrap(function _callee4$(_context4) {
          while (1) {
            switch (_context4.prev = _context4.next) {
              case 0:
                if (!mdRecord) {
                  _context4.next = 27;
                  break;
                }

                console.log("We are being passed the audit details - ", mdRecord);
                vm = _this2;
                // vm.mdbID = mdRecord.mdbID;

                queryParams = { type: "audit", auditId: mdRecord.path };
                queryUri = serviceCall_default.a.genQuery(queryParams);


                vm.showSpinner();
                rslt = {};
                _context4.prev = 7;

                console.log("getAuditData - ", mdRecord);
                console.log("query - ", queryUri);
                _context4.next = 12;
                return axios_default.a.get(queryUri, { headers: _this2.httpHeaders });

              case 12:
                rslt = _context4.sent;

                console.log("getAuditData rslt - ", rslt);

                vm.hideSpinner();
                vm.auditDetails = rslt.data;
                // debugger;
                // console.log("Result - ", rslt);
                // Fake this for now till we can update the metadata to return a 204
                if (rslt.data === "No Matching Records found") {
                  rslt.status = 204;
                }
                return _context4.abrupt("return", rslt);

              case 20:
                _context4.prev = 20;
                _context4.t0 = _context4["catch"](7);
                errState = "initialConnection - " + queryUri + " Query failed - " + stringify_default()(_context4.t0);
                // console.log(errState);

                rslt.status = 204;
                rslt.statusText = errState;
                rslt.data = errState;
                return _context4.abrupt("return", rslt);

              case 27:
              case "end":
                return _context4.stop();
            }
          }
        }, _callee4, _this2, [[7, 20]]);
      }))();
    }
  },

  asyncComputed: {
    getMetadata: {
      get: function get() {
        var _this3 = this;

        return asyncToGenerator_default()( /*#__PURE__*/regenerator_default.a.mark(function _callee5() {
          var vm, columns, p, u, queryParams, queryUri, theResponse;
          return regenerator_default.a.wrap(function _callee5$(_context5) {
            while (1) {
              switch (_context5.prev = _context5.next) {
                case 0:
                  if (!(_this3.PatientLookupResults && _this3.selectedUser)) {
                    _context5.next = 14;
                    break;
                  }

                  // console.log("getMetadata in home.vue - starting lookup of Metadata")
                  vm = _this3;
                  columns = [{ label: "Field Changed", field: "c", sort: true }, {
                    label: "Date",
                    field: "d",
                    sort: true,
                    format: function format(el) {
                      // console.log("Date Data - ", el, moment(el, "YYYYMMDDhhmmss").format("MM/DD/YYYY - hh:mm:ss"));
                      // let y = el.substr(0, 4);
                      // let m = el.substr(4, 2);
                      // let d = el.substr(6, 2);
                      // let h = el.substr(8, 2);
                      // let mi = el.substr(10, 2);
                      // let s = el.substr(12, 2);
                      // let z = el.substr(15, 4);
                      // console.log("Date Data - (2)", el, `${m}/${d}/${y} - ${h}:${mi}:${s} - ${z}Z`);
                      // return `${m}/${d}/${y} - ${h}:${mi}:${s} - ${z}Z`;
                      return moment_default()(el, "YYYYMMDDhhmmss").format("MM/DD/YYYY - hh:mm:ss");
                    }
                  }, {
                    label: "Site data accessed from", field: "l", sort: true
                  }, {
                    label: "File ID", field: "path"
                  }];
                  p = _this3.PatientLookupResults.key;
                  u = _this3.selectedUser;
                  queryParams = { type: "puser", patient: p, user: u };
                  queryUri = serviceCall_default.a.genQuery(queryParams);
                  theResponse = "";

                  eventBus.$emit("wait-for-search", true);
                  vm.showSpinner();
                  _context5.next = 12;
                  return axios_default.a.get(queryUri, { headers: _this3.httpHeaders }).then(function (rslt) {
                    console.log("home - query response 1 - ", rslt);
                    theResponse = { columns: columns, rows: rslt.data };

                    console.log("home - query response - ", theResponse);

                    vm.hideSpinner();
                  }).catch(function (e) {
                    console.log("home - query response - FAILURE - ", e);

                    theResponse = "A Failure - " + e;
                    vm.pageTitle = "Error";
                    vm.hideSpinner();
                  });

                case 12:
                  vm.forceRerender(true);
                  return _context5.abrupt("return", theResponse);

                case 14:
                case "end":
                  return _context5.stop();
              }
            }
          }, _callee5, _this3);
        }))();
      }
    }
  }
});
// CONCATENATED MODULE: ./node_modules/vue-loader/lib/template-compiler?{"id":"data-v-6149aa10","hasScoped":true,"transformToRequire":{"video":["src","poster"],"source":"src","img":"src","image":"xlink:href"},"buble":{"transforms":{}}}!./node_modules/vue-loader/lib/selector.js?type=template&index=0!./src/components/dashboards/home.vue
var home_render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('mdb-container',{attrs:{"fluid":""}},[(_vm.showWaiting)?_c('div',{staticStyle:{"background":"transparent","width":"85%","margin-top":"10%","position":"absolute"},attrs:{"id":"spinner","role":"alert"}},[_c('img',{attrs:{"alt":"waiting","src":"/assets/spinner-yokratom.gif"}})]):_vm._e(),_vm._v(" "),(_vm.State === '' && !_vm.showWaiting)?_c('section',[_c('h2',[_vm._v("How to search")]),_vm._v(" "),_c('mdb-card',{attrs:{"cascade":"","narrow":""}},[_c('mdb-card-body',{staticClass:"pb-0",attrs:{"cascade":""}},[_c('p',{staticStyle:{"text-align":"left"}},[_vm._v("Select the \""),_c('strong',[_vm._v("ENTER PATIENT INFO")]),_vm._v("\" button to enter the\n              "),_c('ul',[_c('li',[_vm._v("Name and Date of Birth")])]),_vm._v(" "),_c('strong',[_vm._v("OR")]),_vm._v(" "),_c('ul',[_c('li',[_vm._v("Name and Social Security number ")])]),_vm._v("\n            of a VA Patient to search for who accessed their records in the VistA environment\n          ")])])],1)],1):_vm._e(),_vm._v(" "),(_vm.State === 'Patient Search Complete' && _vm.PatientLookupResults && _vm.PatientLookupResults.u)?_c('section',[_vm._v("\n      We have a patient, "+_vm._s(_vm.PatientLookupResults.p)+", who has "+_vm._s(_vm.PatientLookupResults.u.length)+" users looking at their records."),_c('br'),_vm._v("\n      Select a user from the list of users to examine what they have accessed.\n    ")]):_vm._e(),_vm._v(" "),(_vm.State === 'User Selected')?_c('section',{staticClass:"metadata_table"},[_c('h2',[_vm._v("Metadata Records")]),_vm._v(" "),_c('h3',[_c('span',{staticClass:"font-weight-bold"},[_vm._v("Patient:")]),_vm._v(" "+_vm._s(_vm.PatientLookupResults.p)+"\n        "),_c('span',{staticClass:"font-weight-bold"},[_vm._v("User:")]),_vm._v(" "+_vm._s(_vm.selectedUser.split("-")[0])+"\n      ")]),_vm._v(" "),(_vm.renderDataTableComponent)?_c('data-table',{ref:"SelectMetadataRecord",attrs:{"PatientLookupResults":_vm.PatientLookupResults,"selectedUser":_vm.selectedUser,"data":_vm.getMetadata}}):_vm._e()],1):_vm._e(),_vm._v(" "),(_vm.State === 'No Data')?_c('section',{attrs:{"id":"no_data"}},[_c('table',{staticClass:"noPatientData"},[_c('caption',[_vm._v("No patients found matching search criteria:")]),_vm._v(" "),_c('tr',[_c('th',{attrs:{"scope":"row"}},[_vm._v("Name: ")]),_c('td',[_vm._v(_vm._s(_vm.patientSearchData.name))])]),_vm._v(" "),_c('tr',[_c('th',{attrs:{"scope":"row"}},[_vm._v("Date of Birth: ")]),_c('td',[_vm._v(_vm._s(_vm.patientSearchData.dob ? _vm.patientSearchData.dob : "Not Entered"))])]),_vm._v(" "),_c('tr',[_c('th',{attrs:{"scope":"row"}},[_vm._v("Social Security Number: ")]),_c('td',[_vm._v(_vm._s(_vm.patientSearchData.ssn ? _vm.patientSearchData.ssn : "Not Entered"))])])])]):_vm._e(),_vm._v(" "),(_vm.State === 'Error')?_c('section',{attrs:{"id":"error"}},[_c('div',{staticClass:"alert alert-danger",attrs:{"role":"alert"}},[_vm._v("\n        Error detected - Network returned "+_vm._s(_vm.Error)+"\n      ")])]):_vm._e(),_vm._v(" "),_c('mdb-select-patient'),_vm._v(" "),_c('mdb-show-audit-details',{attrs:{"showAuditDetails":_vm.showAuditDetails,"auditData":_vm.auditData}})],1)}
var home_staticRenderFns = []
var home_esExports = { render: home_render, staticRenderFns: home_staticRenderFns }
/* harmony default export */ var dashboards_home = (home_esExports);
// CONCATENATED MODULE: ./src/components/dashboards/home.vue
function home_injectStyle (ssrContext) {
  __webpack_require__("Rpu8")
}
var home_normalizeComponent = __webpack_require__("VU/8")
/* script */


/* template */

/* template functional */
var home___vue_template_functional__ = false
/* styles */
var home___vue_styles__ = home_injectStyle
/* scopeId */
var home___vue_scopeId__ = "data-v-6149aa10"
/* moduleIdentifier (server only) */
var home___vue_module_identifier__ = null
var home_Component = home_normalizeComponent(
  home,
  dashboards_home,
  home___vue_template_functional__,
  home___vue_styles__,
  home___vue_scopeId__,
  home___vue_module_identifier__
)

/* harmony default export */ var components_dashboards_home = (home_Component.exports);

// CONCATENATED MODULE: ./src/router/index.js




vue_esm["a" /* default */].use(vue_router_esm["a" /* default */]);

/* harmony default export */ var router = (new vue_router_esm["a" /* default */]({
  routes: [{
    path: '/',
    name: 'Home',
    component: components_dashboards_home
  }]
}));
// EXTERNAL MODULE: ./node_modules/bootstrap-css-only/css/bootstrap.min.css
var bootstrap_min = __webpack_require__("L0+G");
var bootstrap_min_default = /*#__PURE__*/__webpack_require__.n(bootstrap_min);

// EXTERNAL MODULE: ./node_modules/mdbvue/lib/css/mdb.min.css
var mdb_min = __webpack_require__("h7RY");
var mdb_min_default = /*#__PURE__*/__webpack_require__.n(mdb_min);

// EXTERNAL MODULE: ./node_modules/@fortawesome/fontawesome-free/css/all.min.css
var all_min = __webpack_require__("jKqc");
var all_min_default = /*#__PURE__*/__webpack_require__.n(all_min);

// EXTERNAL MODULE: ./node_modules/vue-axios/dist/vue-axios.min.js
var vue_axios_min = __webpack_require__("Rf8U");
var vue_axios_min_default = /*#__PURE__*/__webpack_require__.n(vue_axios_min);

// EXTERNAL MODULE: ./node_modules/vue-async-computed/dist/vue-async-computed.esm.js
var vue_async_computed_esm = __webpack_require__("JJ92");

// CONCATENATED MODULE: ./src/main.js
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "eventBus", function() { return eventBus; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "spinner", function() { return spinner; });
// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.











vue_esm["a" /* default */].use(vue_axios_min_default.a, axios_default.a);
vue_esm["a" /* default */].use(vue_async_computed_esm["a" /* default */]);

var eventBus = new vue_esm["a" /* default */]();
var spinner = new Image();

vue_esm["a" /* default */].config.productionTip = false;

new vue_esm["a" /* default */]({
  router: router,
  render: function render(h) {
    return h(src_App);
  }
}).$mount('#app');

/***/ }),

/***/ "Rpu8":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "SDKv":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "U5C1":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "UfMJ":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "UgDZ":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "f6as":
/***/ (function(module, exports, __webpack_require__) {

var APIBase4P = ;

/**
 *
 *    /howManyRecords - Returns the number of metadata and audit records in the DR
 *    /AuditRecord/{auditId} - Returns a specific Audit Record from the S3 Audit container
 *    /MetaData/{patient} - Returns array of metadata records from Redshift for specified patient
 *        http://localhost:8081/MetaData/LNAME,FNAME MNAME?ssn=434669944
 *        http://localhost:8081/MetaData/LNAME,FNAME MNAME?dob=MMDDYYYY
 *
 *        {"response": {"p":"L_NAME,F_NAME M_NAME","s":"434669944","d":"19370420","u":["57601527"]}}

 *    /MetaData/{patient}/{user} - Returns array of metadata records from Redshift for specified patient/user
 *

 *    [{"_id":"5ee6653139c1063412a9efab",
 *        "p":"VRAG,KELLY-560864778-19532105",
 *        "u":"KAZU,G'KALI-59074875",
 *        "c":"PREFERRED NAME",
 *        "l":"PORTLAND",
 *        "d":"20160904014916-0500"}]


 */

function genQuery(data) {
  console.log("Gen Query - ", data, APIBase4P);
  // console.log("MDB SELECT PATIENT - httpHeaders = ", APIBase4P, httpHeaders)
  switch (data.type) {
    case "patient":
      var url = "";
      if (data.hasOwnProperty("ssn")) {
        url = APIBase4P + "MetaData/" + data.pName + "?ssn=" + data.ssn;
      } else if (data.hasOwnProperty("dob")) {
        var dobA = data.dob.split("/");
        var dob = "" + dobA[2] + dobA[0] + dobA[1];
        url = APIBase4P + "MetaData/" + data.pName + "?dob=" + dob;
      }
      return url;
    case "puser":
      var r = APIBase4P + "MetaData/" + data.patient + "/" + data.user;
      console.log("Gen Query - ", r);
      return r;
    case "audit":
      return APIBase4P + "AuditRecord/" + data.auditId;
  }
}

module.exports = {
  genQuery: genQuery
};

/***/ }),

/***/ "h7RY":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "jKqc":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "pqYQ":
/***/ (function(module, exports) {

// removed by extract-text-webpack-plugin

/***/ }),

/***/ "uslO":
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./af": "3CJN",
	"./af.js": "3CJN",
	"./ar": "3MVc",
	"./ar-dz": "tkWw",
	"./ar-dz.js": "tkWw",
	"./ar-kw": "j8cJ",
	"./ar-kw.js": "j8cJ",
	"./ar-ly": "wPpW",
	"./ar-ly.js": "wPpW",
	"./ar-ma": "dURR",
	"./ar-ma.js": "dURR",
	"./ar-sa": "7OnE",
	"./ar-sa.js": "7OnE",
	"./ar-tn": "BEem",
	"./ar-tn.js": "BEem",
	"./ar.js": "3MVc",
	"./az": "eHwN",
	"./az.js": "eHwN",
	"./be": "3hfc",
	"./be.js": "3hfc",
	"./bg": "lOED",
	"./bg.js": "lOED",
	"./bm": "hng5",
	"./bm.js": "hng5",
	"./bn": "aM0x",
	"./bn.js": "aM0x",
	"./bo": "w2Hs",
	"./bo.js": "w2Hs",
	"./br": "OSsP",
	"./br.js": "OSsP",
	"./bs": "aqvp",
	"./bs.js": "aqvp",
	"./ca": "wIgY",
	"./ca.js": "wIgY",
	"./cs": "ssxj",
	"./cs.js": "ssxj",
	"./cv": "N3vo",
	"./cv.js": "N3vo",
	"./cy": "ZFGz",
	"./cy.js": "ZFGz",
	"./da": "YBA/",
	"./da.js": "YBA/",
	"./de": "DOkx",
	"./de-at": "8v14",
	"./de-at.js": "8v14",
	"./de-ch": "Frex",
	"./de-ch.js": "Frex",
	"./de.js": "DOkx",
	"./dv": "rIuo",
	"./dv.js": "rIuo",
	"./el": "CFqe",
	"./el.js": "CFqe",
	"./en-au": "Sjoy",
	"./en-au.js": "Sjoy",
	"./en-ca": "Tqun",
	"./en-ca.js": "Tqun",
	"./en-gb": "hPuz",
	"./en-gb.js": "hPuz",
	"./en-ie": "ALEw",
	"./en-ie.js": "ALEw",
	"./en-il": "QZk1",
	"./en-il.js": "QZk1",
	"./en-in": "yJfC",
	"./en-in.js": "yJfC",
	"./en-nz": "dyB6",
	"./en-nz.js": "dyB6",
	"./en-sg": "NYST",
	"./en-sg.js": "NYST",
	"./eo": "Nd3h",
	"./eo.js": "Nd3h",
	"./es": "LT9G",
	"./es-do": "7MHZ",
	"./es-do.js": "7MHZ",
	"./es-us": "INcR",
	"./es-us.js": "INcR",
	"./es.js": "LT9G",
	"./et": "XlWM",
	"./et.js": "XlWM",
	"./eu": "sqLM",
	"./eu.js": "sqLM",
	"./fa": "2pmY",
	"./fa.js": "2pmY",
	"./fi": "nS2h",
	"./fi.js": "nS2h",
	"./fil": "rMbQ",
	"./fil.js": "rMbQ",
	"./fo": "OVPi",
	"./fo.js": "OVPi",
	"./fr": "tzHd",
	"./fr-ca": "bXQP",
	"./fr-ca.js": "bXQP",
	"./fr-ch": "VK9h",
	"./fr-ch.js": "VK9h",
	"./fr.js": "tzHd",
	"./fy": "g7KF",
	"./fy.js": "g7KF",
	"./ga": "U5Iz",
	"./ga.js": "U5Iz",
	"./gd": "nLOz",
	"./gd.js": "nLOz",
	"./gl": "FuaP",
	"./gl.js": "FuaP",
	"./gom-deva": "VGQH",
	"./gom-deva.js": "VGQH",
	"./gom-latn": "+27R",
	"./gom-latn.js": "+27R",
	"./gu": "rtsW",
	"./gu.js": "rtsW",
	"./he": "Nzt2",
	"./he.js": "Nzt2",
	"./hi": "ETHv",
	"./hi.js": "ETHv",
	"./hr": "V4qH",
	"./hr.js": "V4qH",
	"./hu": "xne+",
	"./hu.js": "xne+",
	"./hy-am": "GrS7",
	"./hy-am.js": "GrS7",
	"./id": "yRTJ",
	"./id.js": "yRTJ",
	"./is": "upln",
	"./is.js": "upln",
	"./it": "FKXc",
	"./it-ch": "/E8D",
	"./it-ch.js": "/E8D",
	"./it.js": "FKXc",
	"./ja": "ORgI",
	"./ja.js": "ORgI",
	"./jv": "JwiF",
	"./jv.js": "JwiF",
	"./ka": "RnJI",
	"./ka.js": "RnJI",
	"./kk": "j+vx",
	"./kk.js": "j+vx",
	"./km": "5j66",
	"./km.js": "5j66",
	"./kn": "gEQe",
	"./kn.js": "gEQe",
	"./ko": "eBB/",
	"./ko.js": "eBB/",
	"./ku": "kI9l",
	"./ku.js": "kI9l",
	"./ky": "6cf8",
	"./ky.js": "6cf8",
	"./lb": "z3hR",
	"./lb.js": "z3hR",
	"./lo": "nE8X",
	"./lo.js": "nE8X",
	"./lt": "/6P1",
	"./lt.js": "/6P1",
	"./lv": "jxEH",
	"./lv.js": "jxEH",
	"./me": "svD2",
	"./me.js": "svD2",
	"./mi": "gEU3",
	"./mi.js": "gEU3",
	"./mk": "Ab7C",
	"./mk.js": "Ab7C",
	"./ml": "oo1B",
	"./ml.js": "oo1B",
	"./mn": "CqHt",
	"./mn.js": "CqHt",
	"./mr": "5vPg",
	"./mr.js": "5vPg",
	"./ms": "ooba",
	"./ms-my": "G++c",
	"./ms-my.js": "G++c",
	"./ms.js": "ooba",
	"./mt": "oCzW",
	"./mt.js": "oCzW",
	"./my": "F+2e",
	"./my.js": "F+2e",
	"./nb": "FlzV",
	"./nb.js": "FlzV",
	"./ne": "/mhn",
	"./ne.js": "/mhn",
	"./nl": "3K28",
	"./nl-be": "Bp2f",
	"./nl-be.js": "Bp2f",
	"./nl.js": "3K28",
	"./nn": "C7av",
	"./nn.js": "C7av",
	"./oc-lnc": "KOFO",
	"./oc-lnc.js": "KOFO",
	"./pa-in": "pfs9",
	"./pa-in.js": "pfs9",
	"./pl": "7LV+",
	"./pl.js": "7LV+",
	"./pt": "ZoSI",
	"./pt-br": "AoDM",
	"./pt-br.js": "AoDM",
	"./pt.js": "ZoSI",
	"./ro": "wT5f",
	"./ro.js": "wT5f",
	"./ru": "ulq9",
	"./ru.js": "ulq9",
	"./sd": "fW1y",
	"./sd.js": "fW1y",
	"./se": "5Omq",
	"./se.js": "5Omq",
	"./si": "Lgqo",
	"./si.js": "Lgqo",
	"./sk": "OUMt",
	"./sk.js": "OUMt",
	"./sl": "2s1U",
	"./sl.js": "2s1U",
	"./sq": "V0td",
	"./sq.js": "V0td",
	"./sr": "f4W3",
	"./sr-cyrl": "c1x4",
	"./sr-cyrl.js": "c1x4",
	"./sr.js": "f4W3",
	"./ss": "7Q8x",
	"./ss.js": "7Q8x",
	"./sv": "Fpqq",
	"./sv.js": "Fpqq",
	"./sw": "DSXN",
	"./sw.js": "DSXN",
	"./ta": "+7/x",
	"./ta.js": "+7/x",
	"./te": "Nlnz",
	"./te.js": "Nlnz",
	"./tet": "gUgh",
	"./tet.js": "gUgh",
	"./tg": "5SNd",
	"./tg.js": "5SNd",
	"./th": "XzD+",
	"./th.js": "XzD+",
	"./tl-ph": "3LKG",
	"./tl-ph.js": "3LKG",
	"./tlh": "m7yE",
	"./tlh.js": "m7yE",
	"./tr": "k+5o",
	"./tr.js": "k+5o",
	"./tzl": "iNtv",
	"./tzl.js": "iNtv",
	"./tzm": "FRPF",
	"./tzm-latn": "krPU",
	"./tzm-latn.js": "krPU",
	"./tzm.js": "FRPF",
	"./ug-cn": "To0v",
	"./ug-cn.js": "To0v",
	"./uk": "ntHu",
	"./uk.js": "ntHu",
	"./ur": "uSe8",
	"./ur.js": "uSe8",
	"./uz": "XU1s",
	"./uz-latn": "/bsm",
	"./uz-latn.js": "/bsm",
	"./uz.js": "XU1s",
	"./vi": "0X8Q",
	"./vi.js": "0X8Q",
	"./x-pseudo": "e/KL",
	"./x-pseudo.js": "e/KL",
	"./yo": "YXlc",
	"./yo.js": "YXlc",
	"./zh-cn": "Vz2w",
	"./zh-cn.js": "Vz2w",
	"./zh-hk": "ZUyn",
	"./zh-hk.js": "ZUyn",
	"./zh-mo": "+WA1",
	"./zh-mo.js": "+WA1",
	"./zh-tw": "BbgG",
	"./zh-tw.js": "BbgG"
};
function webpackContext(req) {
	return __webpack_require__(webpackContextResolve(req));
};
function webpackContextResolve(req) {
	var id = map[req];
	if(!(id + 1)) // check for number or string
		throw new Error("Cannot find module '" + req + "'.");
	return id;
};
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = "uslO";

/***/ })

},["NHnr"]);
//# sourceMappingURL=app.c01ba6bc9d2bdf4e71d6.js.map